# Tiranex Project 1 – Data Cleaning & Visualization
## Student Performance Data Cleaning and Visualization

Objective: Clean a raw dataset and visualize useful insights using Python.

Completed tasks:
- Missing-value handling
- Duplicate removal
- Outlier handling using IQR
- Visualization using Pandas and Matplotlib
- Basic data storytelling

Files:
- raw_student_performance.csv
- cleaned_student_performance.csv
- project1.py
- three PNG visualizations
- Project_1_Report.pdf
