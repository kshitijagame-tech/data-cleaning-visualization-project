import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("raw_student_performance.csv")

print(df.head())
print(df.info())
print("Missing values:\n", df.isnull().sum())
print("Duplicate rows:", df.duplicated().sum())

df = df.drop_duplicates()

for col in ["Study_Hours", "Attendance"]:
    df[col] = df[col].fillna(df[col].median())

for col in ["Previous_Score", "Final_Score", "Study_Hours", "Attendance"]:
    q1, q3 = df[col].quantile([0.25, 0.75])
    iqr = q3 - q1
    df[col] = df[col].clip(q1 - 1.5*iqr, q3 + 1.5*iqr)

df.to_csv("cleaned_student_performance.csv", index=False)

plt.scatter(df["Study_Hours"], df["Final_Score"], alpha=0.6)
plt.xlabel("Study Hours"); plt.ylabel("Final Score")
plt.title("Study Hours vs Final Score"); plt.show()

df.groupby("Study_Mode")["Final_Score"].mean().plot(kind="bar")
plt.ylabel("Average Final Score"); plt.title("Average Final Score by Study Mode")
plt.show()

plt.hist(df["Final_Score"], bins=15)
plt.xlabel("Final Score"); plt.ylabel("Number of Students")
plt.title("Distribution of Final Scores"); plt.show()
